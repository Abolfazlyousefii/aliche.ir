document.addEventListener('DOMContentLoaded', () => {
    const sidebarToggles = document.querySelectorAll('[data-admin-sidebar-toggle]');
    const sidebarClosers = document.querySelectorAll('[data-admin-sidebar-close]');

    const openSidebar = () => document.body.classList.add('admin-sidebar-open');
    const closeSidebar = () => document.body.classList.remove('admin-sidebar-open');

    sidebarToggles.forEach((button) => {
        button.addEventListener('click', () => {
            if (document.body.classList.contains('admin-sidebar-open')) {
                closeSidebar();
                return;
            }

            openSidebar();
        });
    });

    sidebarClosers.forEach((element) => {
        element.addEventListener('click', closeSidebar);
    });

    window.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeSidebar();
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const sortArea = document.querySelector('[data-menu-sort]');

    if (!sortArea) {
        return;
    }

    let draggedItem = null;

    sortArea.querySelectorAll('[data-menu-item-id]').forEach((item) => {
        item.addEventListener('dragstart', (event) => {
            draggedItem = item;
            item.classList.add('is-dragging');
            event.dataTransfer.effectAllowed = 'move';
        });

        item.addEventListener('dragend', () => {
            item.classList.remove('is-dragging');
            draggedItem = null;
        });
    });

    sortArea.querySelectorAll('[data-menu-list]').forEach((list) => {
        list.addEventListener('dragover', (event) => {
            event.preventDefault();
            const afterElement = getDragAfterElement(list, event.clientY);

            if (!draggedItem || draggedItem.contains(list)) {
                return;
            }

            if (afterElement == null) {
                list.appendChild(draggedItem);
            } else {
                list.insertBefore(draggedItem, afterElement);
            }
        });
    });

    sortArea.querySelector('[data-menu-save-sort]')?.addEventListener('click', async () => {
        const message = sortArea.querySelector('[data-menu-sort-message]');
        const rootList = sortArea.querySelector(':scope > [data-menu-list]');

        if (!rootList) {
            return;
        }

        message.textContent = 'در حال ذخیره...';

        const response = await fetch(sortArea.dataset.sortUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': sortArea.dataset.csrf,
            },
            body: JSON.stringify({ items: serializeMenuList(rootList) }),
        });

        message.textContent = response.ok ? 'ترتیب ذخیره شد.' : 'ذخیره ترتیب با خطا مواجه شد.';
    });
});

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll(':scope > [data-menu-item-id]:not(.is-dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;

        if (offset < 0 && offset > closest.offset) {
            return { offset, element: child };
        }

        return closest;
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function serializeMenuList(list) {
    return [...list.querySelectorAll(':scope > [data-menu-item-id]')].map((item) => {
        const childList = item.querySelector(':scope > [data-menu-list]');

        return {
            id: Number(item.dataset.menuItemId),
            children: childList ? serializeMenuList(childList) : [],
        };
    });
}

function initializeJalaliDatepickers(root = document) {
    const jalaliInputs = root.querySelectorAll('[data-jalali-datepicker]:not([data-jalali-initialized])');

    jalaliInputs.forEach((element) => {
        const dateOnly = element.hasAttribute('data-jalali-date-only');
        element.setAttribute('dir', 'ltr');
        element.setAttribute('inputmode', 'numeric');
        element.setAttribute('placeholder', element.getAttribute('placeholder') || (dateOnly ? '1403/01/15' : '1403/01/15 10:30'));
        element.classList.add('jalali-date-input');
        element.setAttribute('data-jalali-initialized', 'true');
    });

    if (!window.jQuery || !window.jQuery.fn || !window.jQuery.fn.persianDatepicker) {
        return;
    }

    window.jQuery(root).find('[data-jalali-datepicker]').addBack('[data-jalali-datepicker]').each(function initializeJalaliDatepicker() {
        const input = window.jQuery(this);
        const dateOnly = this.hasAttribute('data-jalali-date-only');

        input.persianDatepicker({
            autoClose: true,
            calendar: {
                persian: {
                    locale: 'fa',
                    showHint: true,
                },
            },
            format: dateOnly ? 'YYYY/MM/DD' : 'YYYY/MM/DD HH:mm',
            initialValue: false,
            observer: true,
            timePicker: {
                enabled: !dateOnly,
                meridiem: {
                    enabled: false,
                },
            },
            toolbox: {
                calendarSwitch: {
                    enabled: false,
                },
            },
        });
    });
}

window.initializeJalaliDatepickers = initializeJalaliDatepickers;
document.addEventListener('DOMContentLoaded', () => initializeJalaliDatepickers());

document.addEventListener('DOMContentLoaded', () => {
    const deleteModalElement = document.getElementById('adminDeleteModal');

    if (!deleteModalElement || !window.bootstrap) {
        return;
    }

    const deleteModal = new window.bootstrap.Modal(deleteModalElement);
    const confirmButton = deleteModalElement.querySelector('[data-admin-delete-confirm]');
    const messageElement = deleteModalElement.querySelector('[data-admin-delete-message]');
    let pendingDeleteForm = null;

    document.querySelectorAll('form').forEach((form) => {
        const methodInput = form.querySelector('input[name="_method"]');
        const isDeleteForm = methodInput && methodInput.value.toUpperCase() === 'DELETE';

        if (!isDeleteForm) {
            return;
        }

        form.setAttribute('data-admin-delete-form', 'true');

        form.addEventListener('submit', (event) => {
            if (form.dataset.adminDeleteConfirmed === 'true') {
                return;
            }

            event.preventDefault();
            pendingDeleteForm = form;

            if (messageElement) {
                const rowTitle = form.closest('tr')?.querySelector('strong')?.textContent?.trim();
                messageElement.textContent = rowTitle ? `مورد انتخاب‌شده: ${rowTitle}` : '';
            }

            deleteModal.show();
        });
    });

    confirmButton?.addEventListener('click', () => {
        if (!pendingDeleteForm) {
            return;
        }

        pendingDeleteForm.dataset.adminDeleteConfirmed = 'true';
        deleteModal.hide();
        pendingDeleteForm.requestSubmit();
    });

    deleteModalElement.addEventListener('hidden.bs.modal', () => {
        if (pendingDeleteForm?.dataset.adminDeleteConfirmed !== 'true') {
            pendingDeleteForm = null;
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const markPageReady = () => {
        document.documentElement.classList.remove('loading', 'is-loading', 'admin-loading');
        document.body.classList.remove('loading', 'is-loading', 'admin-loading');
        document.body.classList.add('admin-page-ready');
    };

    markPageReady();
    window.addEventListener('load', markPageReady);
    window.addEventListener('pageshow', markPageReady);

    document.querySelectorAll('[data-admin-pagination] a[href]').forEach((link) => {
        link.addEventListener('click', (event) => {
            const href = link.getAttribute('href');

            if (!href || href === '#' || link.getAttribute('aria-disabled') === 'true') {
                event.preventDefault();
                markPageReady();
                return;
            }

            link.dataset.adminPaginationClicked = 'true';
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('form[data-single-submit]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (form.dataset.submitted === 'true') {
                event.preventDefault();
                return;
            }

            form.dataset.submitted = 'true';
            const submitter = event.submitter || form.querySelector('button[type="submit"], input[type="submit"]');

            if (submitter) {
                const loadingText = submitter.getAttribute('data-loading-text');
                if (loadingText && 'textContent' in submitter) {
                    submitter.textContent = loadingText;
                }
                submitter.setAttribute('aria-disabled', 'true');
                submitter.disabled = true;
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const pickerUrl = window.adminMediaPickerUrl;

    if (!pickerUrl) {
        return;
    }

    let mediaItems = [];
    let mediaLoaded = false;
    let activePicker = null;

    const ensureModal = () => {
        let modal = document.querySelector('[data-admin-media-picker-modal]');
        if (modal) return modal;

        modal = document.createElement('div');
        modal.className = 'admin-wp-media-modal';
        modal.setAttribute('data-admin-media-picker-modal', '');
        modal.hidden = true;
        modal.innerHTML = `
            <div class="admin-wp-modal-backdrop" data-admin-media-picker-close></div>
            <div class="admin-wp-modal-dialog admin-media-picker-dialog" role="dialog" aria-modal="true" aria-label="انتخاب تصویر از کتابخانه">
                <header><strong>انتخاب تصویر از کتابخانه</strong><button type="button" data-admin-media-picker-close>×</button></header>
                <div class="admin-media-picker-modal-body">
                    <div class="admin-media-picker-modal-main">
                        <div class="admin-wp-toolbar"><input class="form-control" type="search" placeholder="جستجوی تصویر..." data-admin-media-picker-search><small data-admin-media-picker-status>در حال دریافت تصاویر...</small></div>
                        <div class="admin-wp-media-grid" data-admin-media-picker-grid></div>
                    </div>
                    <aside class="admin-media-picker-sidebar"><strong>پیش‌نمایش انتخاب</strong><div data-admin-media-picker-preview class="admin-media-picker-preview"><span>یک تصویر انتخاب کنید.</span></div><button class="admin-primary-btn w-100 mt-3" type="button" data-admin-media-picker-apply disabled>انتخاب تصویر</button></aside>
                </div>
            </div>`;
        document.body.appendChild(modal);
        modal.querySelectorAll('[data-admin-media-picker-close]').forEach((button) => button.addEventListener('click', () => { modal.hidden = true; }));
        modal.querySelector('[data-admin-media-picker-search]')?.addEventListener('input', () => renderModal());
        modal.querySelector('[data-admin-media-picker-grid]')?.addEventListener('click', (event) => {
            const tile = event.target.closest('[data-admin-media-picker-item]');
            if (!tile || !activePicker) return;
            const id = tile.dataset.id;
            if (activePicker.multiple) {
                activePicker.selectedIds.has(id) ? activePicker.selectedIds.delete(id) : activePicker.selectedIds.add(id);
            } else {
                activePicker.selectedIds = new Set([id]);
            }
            renderModal();
        });
        modal.querySelector('[data-admin-media-picker-apply]')?.addEventListener('click', () => {
            if (!activePicker) return;
            activePicker.onApply([...activePicker.selectedIds]);
            modal.hidden = true;
        });
        return modal;
    };

    const loadMedia = async () => {
        if (mediaLoaded) return mediaItems;
        const response = await fetch(pickerUrl, { headers: { Accept: 'application/json' } });
        const data = await response.json();
        mediaItems = data.items || [];
        mediaLoaded = true;
        return mediaItems;
    };

    const renderModal = () => {
        const modal = ensureModal();
        const grid = modal.querySelector('[data-admin-media-picker-grid]');
        const status = modal.querySelector('[data-admin-media-picker-status]');
        const preview = modal.querySelector('[data-admin-media-picker-preview]');
        const apply = modal.querySelector('[data-admin-media-picker-apply]');
        const search = (modal.querySelector('[data-admin-media-picker-search]')?.value || '').trim().toLowerCase();
        const items = mediaItems.filter((item) => !search || `${item.title || ''} ${item.alt || ''}`.toLowerCase().includes(search));
        grid.innerHTML = items.map((item) => `<button class="admin-wp-media-tile${activePicker?.selectedIds.has(String(item.id)) ? ' is-selected' : ''}" type="button" data-admin-media-picker-item data-id="${item.id}"><img src="${item.url}" alt="${item.alt || item.title || ''}"><span class="admin-wp-media-check">✓</span><span class="admin-wp-media-title">${item.title || 'تصویر'}</span></button>`).join('') || '<p class="text-muted p-3">تصویری در کتابخانه پیدا نشد.</p>';
        const chosen = mediaItems.filter((item) => activePicker?.selectedIds.has(String(item.id)));
        preview.innerHTML = chosen.length ? chosen.map((item) => `<figure><img src="${item.url}" alt="${item.alt || item.title || ''}"><figcaption>${item.title || 'تصویر'}</figcaption></figure>`).join('') : '<span>یک تصویر انتخاب کنید.</span>';
        status.textContent = mediaLoaded ? `${items.length} تصویر آماده انتخاب است.` : 'در حال دریافت تصاویر...';
        apply.disabled = chosen.length === 0;
        apply.textContent = activePicker?.multiple ? 'انتخاب تصاویر' : 'انتخاب تصویر';
    };

    const openPicker = async ({ multiple = false, selectedIds = [], onApply }) => {
        const modal = ensureModal();
        activePicker = { multiple, selectedIds: new Set(selectedIds.map(String).filter(Boolean)), onApply };
        modal.hidden = false;
        renderModal();
        await loadMedia();
        renderModal();
    };

    document.querySelectorAll('[data-media-select-target]').forEach((button) => {
        button.addEventListener('click', () => {
            const select = document.getElementById(button.dataset.mediaSelectTarget);
            if (!select) return;
            const multiple = button.dataset.mediaSelectMultiple === 'true' || select.multiple;
            openPicker({
                multiple,
                selectedIds: [...select.selectedOptions].map((option) => option.value),
                onApply: (ids) => {
                    if (select.tomselect) {
                        select.tomselect.setValue(multiple ? ids : (ids[0] || ''), true);
                    } else {
                        [...select.options].forEach((option) => { option.selected = ids.includes(option.value); });
                    }
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                },
            });
        });
    });

    const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]:not([data-skip-media-picker])');
    imageInputs.forEach((input) => {
        if (!input.name || input.dataset.mediaPickerReady === 'true') return;
        input.dataset.mediaPickerReady = 'true';
        const isMultiple = input.multiple || input.name.endsWith('[]');
        const baseName = input.name.replace(/\[\]$/, '');
        const hiddenName = isMultiple ? `${baseName}_media_ids[]` : `${baseName}_media_id`;
        const wrapper = document.createElement('div');
        wrapper.className = 'admin-media-picker mt-2';
        wrapper.innerHTML = `<button class="admin-secondary-btn" type="button" data-media-picker-open>انتخاب از کتابخانه با پیش‌نمایش</button><small class="text-muted d-block mt-2" data-media-picker-status>می‌توانید به‌جای آپلود فایل جدید، عکس را از کتابخانه انتخاب کنید.</small><div class="row g-2 mt-2" data-media-picker-selected></div>`;
        input.insertAdjacentElement('afterend', wrapper);
        const selected = wrapper.querySelector('[data-media-picker-selected]');
        const status = wrapper.querySelector('[data-media-picker-status]');
        const renderSelected = (ids) => {
            selected.innerHTML = ids.map((id) => {
                const item = mediaItems.find((media) => String(media.id) === String(id));
                return item ? `<div class="col-4 col-md-3" data-media-picker-selection><div class="border rounded p-1 position-relative"><input type="hidden" name="${hiddenName}" value="${item.id}"><img src="${item.url}" alt="${item.title || ''}" class="img-fluid rounded" style="height:82px;width:100%;object-fit:cover"><button type="button" class="btn btn-sm btn-light position-absolute top-0 start-0" data-media-picker-remove aria-label="حذف">×</button></div></div>` : '';
            }).join('');
        };
        wrapper.querySelector('[data-media-picker-open]')?.addEventListener('click', () => openPicker({
            multiple: isMultiple,
            selectedIds: [...selected.querySelectorAll('input[type="hidden"]')].map((hidden) => hidden.value),
            onApply: (ids) => { renderSelected(ids); status.textContent = isMultiple ? 'تصاویر از کتابخانه انتخاب شدند.' : 'تصویر از کتابخانه انتخاب شد.'; },
        }));
        selected.addEventListener('click', (event) => {
            if (event.target.closest('[data-media-picker-remove]')) event.target.closest('[data-media-picker-selection]')?.remove();
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const slugify = (value) => value
        .trim()
        .replace(/[\s_\u200c]+/g, '-')
        .replace(/[^\u0600-\u06FF\p{L}\p{N}-]+/gu, '')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .toLowerCase();

    document.querySelectorAll('form').forEach((form) => {
        const titleInput = form.querySelector('#title, [name="title"]');
        const slugInput = form.querySelector('#slug, [name="slug"]');

        if (!titleInput || !slugInput || slugInput.dataset.autoSlugReady === 'true') {
            return;
        }

        slugInput.dataset.autoSlugReady = 'true';
        let slugTouched = Boolean(slugInput.value.trim());

        slugInput.addEventListener('input', () => {
            slugTouched = Boolean(slugInput.value.trim());
        });

        titleInput.addEventListener('input', () => {
            if (slugTouched) {
                return;
            }

            slugInput.value = slugify(titleInput.value);
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.querySelector('[data-media-modal]');
    const modalBody = document.querySelector('[data-media-modal-body]');
    const tiles = document.querySelectorAll('[data-media-tile]');

    if (modal && modalBody) {
        const close = () => {
            modal.hidden = true;
            modalBody.innerHTML = '';
            tiles.forEach((tile) => tile.classList.remove('is-selected'));
        };

        document.querySelectorAll('[data-media-modal-close]').forEach((button) => button.addEventListener('click', close));
        tiles.forEach((tile) => {
            const open = () => {
                const template = tile.querySelector('template[data-media-details]');
                if (!template) return;
                tiles.forEach((item) => item.classList.remove('is-selected'));
                tile.classList.add('is-selected');
                modalBody.innerHTML = template.innerHTML;
                modal.hidden = false;
            };
            tile.addEventListener('click', open);
            tile.addEventListener('keydown', (event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    open();
                }
            });
        });
        modalBody.addEventListener('click', async (event) => {
            const copyButton = event.target.closest('[data-copy-url]');
            if (!copyButton) return;
            await navigator.clipboard.writeText(copyButton.dataset.copyUrl || '');
            copyButton.textContent = 'کپی شد';
        });
        window.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && !modal.hidden) close();
        });
    }

    document.querySelectorAll('[data-media-dropzone]').forEach((form) => {
        const input = form.querySelector('input[type="file"]');
        const count = form.querySelector('[data-media-file-count]');
        if (!input || !count) return;
        const updateCount = () => {
            count.textContent = input.files.length ? `${input.files.length} فایل آماده آپلود است.` : 'هیچ فایلی انتخاب نشده است.';
        };
        input.addEventListener('change', updateCount);
        form.addEventListener('dragover', (event) => {
            event.preventDefault();
            form.classList.add('is-dragover');
        });
        form.addEventListener('dragleave', () => form.classList.remove('is-dragover'));
        form.addEventListener('drop', (event) => {
            event.preventDefault();
            form.classList.remove('is-dragover');
            if (event.dataTransfer?.files?.length) {
                input.files = event.dataTransfer.files;
                updateCount();
            }
        });
    });

    document.querySelectorAll('input[name="sort_order"], input[name$="[sort_order]"]').forEach((input) => {
        if (input.dataset.sortHelpReady === 'true') return;
        input.dataset.sortHelpReady = 'true';
        input.insertAdjacentHTML('afterend', '<small class="sort-order-help"><strong>راهنما:</strong> عدد کمتر زودتر و بالاتر نمایش داده می‌شود؛ برای ترتیب دقیق از ۱۰، ۲۰، ۳۰ استفاده کنید تا بین موارد جا داشته باشید.</small>');
    });
});
